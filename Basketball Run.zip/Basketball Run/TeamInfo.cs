/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Represents team information for a playoff scoring record.
*******************************************************************/
public class TeamInfo
{
    public string TeamName { get; private set; }

    public TeamInfo(string teamName)
    {
        TeamName = teamName;
    }

    public override string ToString()
    {
        return TeamName;
    }
}