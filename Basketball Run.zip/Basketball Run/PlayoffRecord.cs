/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Represents a player's high-scoring playoff game.
*******************************************************************/
public class PlayoffRecord : PlayerRecord
{
    public int ScoringHigh { get; private set; }

    public PlayoffRecord(int id, string playerName, int playerNumber, TeamInfo team, int scoringHigh)
        : base(id, playerName, playerNumber, team)
    {
        ScoringHigh = scoringHigh;
    }

    public PlayoffRecord(string playerName, int playerNumber, TeamInfo team, int scoringHigh)
        : base(playerName, playerNumber, team)
    {
        ScoringHigh = scoringHigh;
    }

    public override string GetRecordType()
    {
        return "NBA Playoff Scoring High";
    }

    public override string GetDisplayInfo()
    {
        return base.GetDisplayInfo() +
               "\nRecord Type: " + GetRecordType() +
               "\nScoring High: " + ScoringHigh;
    }

    public override string ToString()
    {
        return GetDisplayInfo();
    }
}