using System;
using System.Data.SQLite;

/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Handles connecting to the SQLite database.
*******************************************************************/
public class SQLiteDatabase
{
    public static SQLiteConnection Connect(string database)
    {
        SQLiteConnection conn = new SQLiteConnection("Data Source=" + database);

        try
        {
            conn.Open();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

        return conn;
    }
}