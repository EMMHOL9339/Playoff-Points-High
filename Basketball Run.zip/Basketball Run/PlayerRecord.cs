/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Abstract base class for player records.
*******************************************************************/
public abstract class PlayerRecord : IRecord
{
    public int Id { get; set; }
    public string PlayerName { get; protected set; }
    public int PlayerNumber { get; protected set; }
    public TeamInfo Team { get; protected set; }

    public PlayerRecord(int id, string playerName, int playerNumber, TeamInfo team)
    {
        Id = id;
        PlayerName = playerName;
        PlayerNumber = playerNumber;
        Team = team;
    }

    public PlayerRecord(string playerName, int playerNumber, TeamInfo team)
    {
        PlayerName = playerName;
        PlayerNumber = playerNumber;
        Team = team;
    }

    public abstract string GetRecordType();

    public virtual string GetDisplayInfo()
    {
        return "Record ID: " + Id +
               "\nPlayer Name: " + PlayerName +
               "\nPlayer Number: " + PlayerNumber +
               "\nTeam: " + Team;
    }
}