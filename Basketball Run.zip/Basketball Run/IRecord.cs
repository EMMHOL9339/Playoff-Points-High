/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Interface for records that can display information.
*******************************************************************/
public interface IRecord
{
    string GetDisplayInfo();
}