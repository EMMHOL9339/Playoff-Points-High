using System.Collections.Generic;
using System.Data.SQLite;

/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Handles CRUD database operations for playoff scoring records.
*******************************************************************/
public class PlayoffRecordDB
{
    public static void CreateTable(SQLiteConnection conn)
    {
        string sql =
            "CREATE TABLE IF NOT EXISTS PlayoffRecords (" +
            "Id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "PlayerName TEXT, " +
            "PlayerNumber INTEGER, " +
            "TeamName TEXT, " +
            "ScoringHigh INTEGER);";

        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }

    public static void AddRecord(SQLiteConnection conn, PlayoffRecord record)
    {
        string sql =
            "INSERT INTO PlayoffRecords(PlayerName, PlayerNumber, TeamName, ScoringHigh) " +
            "VALUES(@name, @number, @team, @high);";

        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.Parameters.AddWithValue("@name", record.PlayerName);
        cmd.Parameters.AddWithValue("@number", record.PlayerNumber);
        cmd.Parameters.AddWithValue("@team", record.Team.TeamName);
        cmd.Parameters.AddWithValue("@high", record.ScoringHigh);
        cmd.ExecuteNonQuery();
    }

    public static List<PlayoffRecord> GetAllRecords(SQLiteConnection conn)
    {
        List<PlayoffRecord> records = new List<PlayoffRecord>();

        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT * FROM PlayoffRecords;";

        SQLiteDataReader rdr = cmd.ExecuteReader();

        while (rdr.Read())
        {
            records.Add(new PlayoffRecord(
                rdr.GetInt32(0),
                rdr.GetString(1),
                rdr.GetInt32(2),
                new TeamInfo(rdr.GetString(3)),
                rdr.GetInt32(4)
            ));
        }

        return records;
    }

    public static void UpdateRecord(SQLiteConnection conn, PlayoffRecord record)
    {
        string sql =
            "UPDATE PlayoffRecords SET PlayerName=@name, PlayerNumber=@number, TeamName=@team, ScoringHigh=@high " +
            "WHERE Id=@id;";

        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.Parameters.AddWithValue("@id", record.Id);
        cmd.Parameters.AddWithValue("@name", record.PlayerName);
        cmd.Parameters.AddWithValue("@number", record.PlayerNumber);
        cmd.Parameters.AddWithValue("@team", record.Team.TeamName);
        cmd.Parameters.AddWithValue("@high", record.ScoringHigh);
        cmd.ExecuteNonQuery();
    }

    public static void DeleteRecord(SQLiteConnection conn, int id)
    {
        SQLiteCommand cmd = conn.CreateCommand();
        cmd.CommandText = "DELETE FROM PlayoffRecords WHERE Id=@id;";
        cmd.Parameters.AddWithValue("@id", id);
        cmd.ExecuteNonQuery();
    }
}