﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

/*******************************************************************
* Name: Emmanuel Holmes
* Date: 5/3/2026
* Assignment: SDC320 Final Project
*
* Main program for the NBA Playoff Scoring High Tracker.
*******************************************************************/
public class Program
{
    private static SQLiteConnection conn;

    public static void Main(string[] args)
    {
        conn = SQLiteDatabase.Connect("PlayoffScoringHighs.db");
        PlayoffRecordDB.CreateTable(conn);

        Console.WriteLine("Emmanuel Holmes - NBA Playoff Scoring High Tracker");
        Console.WriteLine("This program lets you add, view, update, and delete playoff scoring records.\n");

        bool running = true;

        while (running)
        {
            Console.WriteLine("\nMenu");
            Console.WriteLine("1. Add Scoring Record");
            Console.WriteLine("2. View All Records");
            Console.WriteLine("3. Update Record");
            Console.WriteLine("4. Delete Record");
            Console.WriteLine("5. Exit");
            Console.Write("Choose an option: ");

            string choice = Console.ReadLine();

            if (choice == "1")
                AddRecord();
            else if (choice == "2")
                ViewRecords();
            else if (choice == "3")
                UpdateRecord();
            else if (choice == "4")
                DeleteRecord();
            else if (choice == "5")
                running = false;
            else
                Console.WriteLine("Invalid option.");
        }

        Console.WriteLine("Program ended.");
    }

    private static void AddRecord()
    {
        Console.Write("\nPlayer Name: ");
        string name = Console.ReadLine();

        Console.Write("Player Number: ");
        int number = int.Parse(Console.ReadLine());

        Console.Write("Team: ");
        string team = Console.ReadLine();

        Console.Write("Scoring High: ");
        int high = int.Parse(Console.ReadLine());

        PlayoffRecord record = new PlayoffRecord(name, number, new TeamInfo(team), high);
        PlayoffRecordDB.AddRecord(conn, record);

        Console.WriteLine("Record added.");
    }

    private static void ViewRecords()
    {
        Console.WriteLine("\nAll Playoff Scoring Records");

        List<PlayoffRecord> records = PlayoffRecordDB.GetAllRecords(conn);

        if (records.Count == 0)
        {
            Console.WriteLine("No records found.");
            return;
        }

        foreach (PlayoffRecord record in records)
        {
            Console.WriteLine("\n" + record);
            Console.WriteLine("-------------------------");
        }
    }

    private static void UpdateRecord()
    {
        ViewRecords();

        Console.Write("\nEnter Record ID to update: ");
        int id = int.Parse(Console.ReadLine());

        Console.Write("New Player Name: ");
        string name = Console.ReadLine();

        Console.Write("New Player Number: ");
        int number = int.Parse(Console.ReadLine());

        Console.Write("New Team: ");
        string team = Console.ReadLine();

        Console.Write("New Scoring High: ");
        int high = int.Parse(Console.ReadLine());

        PlayoffRecord updatedRecord = new PlayoffRecord(id, name, number, new TeamInfo(team), high);
        PlayoffRecordDB.UpdateRecord(conn, updatedRecord);

        Console.WriteLine("Record updated.");
    }

    private static void DeleteRecord()
    {
        ViewRecords();

        Console.Write("\nEnter Record ID to delete: ");
        int id = int.Parse(Console.ReadLine());

        PlayoffRecordDB.DeleteRecord(conn, id);

        Console.WriteLine("Record deleted.");
    }
}